<?php 

    $title = "MVC_STORE: PRODUITS";

    ob_start();

?>

<h1 class="text-center">Nos Produits</h1>

 <!-- TODO Afficher les produits -->

<?php 
    $content = ob_get_clean();
    require "view/template.php";
?>